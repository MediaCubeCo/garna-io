# Blog engine

Private Cloudflare Workers/D1/R2 blog engine. One codebase, independent deployments,
databases, media, editors and content. First consumer: Garna. The Mediacube example
does not modify the existing Mediacube WordPress/Gatsby site.

## Development

Use Node.js 24 and npm. Run `npm ci`, `npm run build`, `npm run check`, `npm test`.
`npm pack` builds the distributable (including pinned EditorJS tools, CSS and
structural SQL). Tests use local Miniflare D1/R2; no production access is required.
For consumer development install the resulting `.tgz`, not a source symlink.
Generated assets/templates and `dist` are not source files. Edit `src/templates`
and `src/public.css`; the build creates immutable version-and-content-hash URLs.

## Install

Add `@mediacubeco:registry=https://npm.pkg.github.com` to the consumer `.npmrc`.
Authenticate locally with a classic PAT with `read:packages` (and required
organization authorization). Keep tokens in user configuration/environment, never
commit them. In Actions use `GITHUB_TOKEN` with `packages: read`, after granting
the consumer repository access in the package's **Manage Actions access** settings.

```sh
npm install --save-exact @mediacubeco/blog-engine@1.4.1
npx blog-migrations migrations
```

`examples/mediacube` is a complete separate Worker. Its resource IDs are deliberately
placeholders: apply its migrations locally; provision separate resources before
deploying it. Never substitute Garna resource IDs.

## API and integration

```ts
import { createBlog } from '@mediacubeco/blog-engine';

const blog = createBlog({
  brand: { name: 'Example', title: 'Example Journal', description: 'Our articles' },
  origin: 'https://example.com',
  locales: [{ value: 'en', label: 'English' }],
  defaultLanguage: 'en',
  cookieName: 'example_blog_session',
  theme: { '--blog-accent': '#fe365c', '--blog-background': '#15131a' },
});

export default {
  async fetch(request, env) {
    return await blog.handle(request, env) || new Response('Not found', { status: 404 });
  },
};
```

`createBlog(config)` does not capture request bindings. `handle(request, bindings)`
returns `Response | null`; call it before your site's fallback. `getSitemapEntries`
returns absolute published URLs for a configured locale. The site owns its sitemap
document and legacy redirects. Types and `createBlogRenderers` are exported; SQL
helpers are internal and are not a supported import path.

Default paths: `/:locale/blog`, `/admin/blog`, `/admin/api/blog`, `/admin/api/auth`,
`/blog-media`, `/blog-assets`. Configure the respective `paths` properties to change
prefixes. Register Worker-first routes if a site's static assets can intercept them.

Request bindings: `DB` (D1), `BLOG_MEDIA` (R2), `ADMIN_EMAILS` (comma-separated),
`SESSION_SECRET`, `MAGIC_LINK_SECRET`; production email uses `EMAIL.send(message)`
and `EMAIL_FROM`. Secrets must be independently generated for each installation.
Missing authentication secrets are errors, not development defaults. Sessions and
magic links use database-backed hashed tokens. Allowed editors are rechecked.
`DEV_SHOW_MAGIC_LINK=true` is only a localhost development convenience; never enable
it as a production login mechanism.

Existing Garna cookies, table/record IDs, `body_markdown`, special block syntax,
media keys and URLs are retained. `body_markdown` remains a renderer fallback for
consumers that have not applied the document migration.
The editor supports metrics (1–4), highlighted quotes, linked-list cards, and tables.
These are serialized as `{{mcblock:<base64-json>}}` in `body_markdown`; existing
Mediacube articles with this syntax render without migration or resaving.
Publication dates are evaluated on reads; future-dated posts remain private until
their time arrives. Preview requires an editor session and sends `no-store` and
`noindex`. Article language alternates include only published versions.

## Canonical article documents

Version 1.4 exports `ArticleDocumentV1`, `ArticleBlock`,
`ArticleTranslationState`, document/Markdown converters, structure/content hash
helpers, and the server-side translation structure assertion. A migrated article
uses `body_document` as the source of truth; the server regenerates
`body_markdown` for backwards compatibility. Block IDs, order, heading levels,
list/table shapes, media URLs and other immutable properties participate in the
structure hash. Translatable text participates in the content hash.

Translation saves go to `article_translation_drafts`. Publishing validates the
draft against the current English document and atomically replaces the public
translation, FAQ rows and draft with `D1Database.batch()`. Existing public rows
remain readable and in sitemap/hreflang while their status is `source_updated` or
`structure_outdated`.

Category names and descriptions are authored in English in the category editor.
English is required even if a site's default article language differs. Each other
configured locale has optional fields in the same editor. A missing or empty
translated field falls back to English on category filters, cards and articles;
category slugs and article assignments stay shared across languages. Apply the
category translation migration to each installation before upgrading its Worker.
The editor also accepts optional SEO title and description for English and each
configured locale. Empty localized SEO fields fall back to English; when English
SEO fields are empty, the category name and description provide the page defaults.
Apply migration 0013 before using these fields.

## Branding and page shell

The default shell works without Astro/React. Public renderers provide list/cards,
article/TOC/FAQ/author markup, CSS and interactive scripts. Historical CSS class
names are retained for Garna compatibility; they do not connect installations.
`theme` accepts `--blog-*` CSS variables (accent, background, font).
`brand` controls visible and SEO text/image. `cta` configures the default CTA.

`renderShell({ title, head, body, language }, bindings)` optionally wraps the result
in the consumer's header/footer. Insert `head` and `body` once and supply site CSS
or include the engine stylesheet. Do not interpolate content into JavaScript.
`slots.listCta`, `sideBanner`, `inlineCta(data)` and `contact` are trusted server-code
HTML extension points. They are NOT user-editable HTML. Escape any article data
used in callbacks (`escapeHtml`/`escapeAttribute`). The package escapes user content;
the consumer is responsible for HTML it explicitly supplies. Site forms, booking
widgets, analytics and redirects remain in the consumer. No secrets/server modules
are served by the public assets handler.

## Migrations

The package contains the original, byte-identical structural migrations 0001,
0003, 0005–0010 plus 0012 for category translations, 0013 for category SEO and
0015 for canonical article documents/translation drafts. Seed migrations 0002
and 0004 are intentionally absent. On a new database this sequence produces an
empty blog. The 0012 migration only adds a table and is safe for old Workers.

`blog-migrations <directory>` checks ALL existing destination files for conflicts
before adding missing files; repeat runs add nothing. It never connects to a DB or
applies SQL. Keep Garna's full existing migration directory/history, including its
old seeds. Existing applied names remain recognized by Wrangler. Do not rename,
rewrite or delete old SQL. Never run migrations during npm install or HTTP requests.
Apply locally with `wrangler d1 migrations apply <database> --local`. Applying remote
migrations is a separate reviewed deployment operation.

## Release and update

1. Run checks and install the exact `npm pack` archive in both consumers. Verify
   TypeScript, builds, Worker dry-run and editor/public flows.
2. Merge the package PR/change, set a new exact semver version and lockfile, and
   publish GitHub release `v<version>`. Actions verifies before publishing with
   `GITHUB_TOKEN`; package publication does not deploy any site.
3. Grant each consumer repository package read access. In the consumer update the
   exact dependency plus lockfile, sync migrations, review the diff and test.
4. Back up D1, record migration history and current Worker deployment/version before
   deploying. Keep backups out of git and restrict access (they contain user data).
5. Deploy that consumer only. Smoke list/article/author, media, sitemap, canonical,
   login, draft save/reopen, authorized preview, unauthorized refusal and publication.

Rollback to the recorded Worker version (`wrangler rollback <version-id>`) if smoke
checks regress. The additive category table can remain in place for an old Worker;
do not drop it during rollback. Restore data only for an actual data incident,
not as a routine code rollback.

## Verification limits

Tests exercise local schema creation, migration conflicts/repeatability, auth token
reuse/expiry, two-instance isolation, drafts/scheduled publication, translation,
HTML escaping, R2 and sitemap. Browser/production verification is a release gate,
not something inferred from a passing build. Local tooling currently reports a
transitive `sharp`/libheif advisory in Wrangler/Miniflare dev dependencies; the
published engine has no runtime npm dependencies. Do not process untrusted HEIF
files with affected local tooling; track the upstream fix rather than downgrading
Wrangler blindly.
